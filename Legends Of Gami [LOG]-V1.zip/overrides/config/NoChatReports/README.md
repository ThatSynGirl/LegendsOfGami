# No Chat Reports
You can find updated documentation of configuration files on the wiki:
https://github.com/Aizistral-Studios/No-Chat-Reports/wiki/Configuration-Files
